//
//  ViewController.swift
//  CreateTableViewSwift
//
//  Created by Siya Infotech on 04/08/15.
//  Copyright (c) 2015 Siya Infotech. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource{
    
    @IBOutlet var tblList: UITableView!
    @IBOutlet var lblDetail: UILabel!
    var itemList : NSMutableArray = []
    var selectedItemList : NSMutableArray = []
    override func viewDidLoad() {
        super.viewDidLoad()
        self.loadDataFromServer()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
//    MARK: - UITableView -
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return itemList.count
    }
    func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool{
        return true
    }
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("Cell", forIndexPath: indexPath) as UITableViewCell
        
        let roleInfo : NSDictionary?=itemList.objectAtIndex(indexPath.row) as? NSDictionary
        cell.textLabel!.text = roleInfo?.valueForKey("MenuName") as NSString
        cell.accessoryType = UITableViewCellAccessoryType.None
        if selectedItemList.containsObject(roleInfo?.valueForKey("MenuName") as NSString){
            cell.accessoryType = .Checkmark
        }
        return cell
    }
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let roleInfo : NSDictionary?=itemList.objectAtIndex(indexPath.row) as? NSDictionary
        lblDetail.text = roleInfo?.valueForKey("MenuName") as NSString
        if !selectedItemList.containsObject(roleInfo?.valueForKey("MenuName") as NSString){
            selectedItemList.removeAllObjects()
            selectedItemList.addObject(roleInfo?.valueForKey("MenuName") as NSString)
        }
        tableView.reloadData()
    }
    func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath)
    {
        if editingStyle == UITableViewCellEditingStyle.Delete {
            itemList.removeObjectAtIndex(indexPath.row)
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: UITableViewRowAnimation.Automatic)
        }
    }
    
//    MARK: - WebConnection -
    func loadDataFromServer(){
        UIApplication.sharedApplication().networkActivityIndicatorVisible = true
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "userLogInResponce:", name:"LoginResponseResult", object: nil)
        var obje = WebConnectionManager()
        var mutableDict:NSMutableDictionary = NSMutableDictionary()
        mutableDict.setValue("1", forKey: "BranchId")
        mutableDict.setValue("1050", forKey: "Psw")
        mutableDict.setValue("128", forKey: "RegisterId")

        obje.ConnectWithPOST("http://rapidrmswebsite.trafficmanager.net/WcfService/Service.svc/UserPasscodeLogin", ActionName: "UserPasscodeLogin", WithParamiterList:mutableDict , NotificationName: "LoginResponseResult")
    }
    
    func userLogInResponce(notification : NSNotification) {
        UIApplication.sharedApplication().networkActivityIndicatorVisible = false
        var jsonResult: NSDictionary? = notification.userInfo
        var UserPasscodeLoginResult: NSDictionary? = jsonResult?.objectForKey("UserPasscodeLoginResult") as? NSDictionary
        
        var UserData: NSString? = UserPasscodeLoginResult?.valueForKeyPath("Data") as? NSString
        
        var jsonData :NSData? = UserData?.dataUsingEncoding(NSUTF8StringEncoding)
        var error :NSError?
        let userInfo: NSArray? = NSJSONSerialization.JSONObjectWithData(jsonData!, options: nil,error: &error) as? NSArray
        
        let userDataInfo : NSDictionary? = userInfo?.firstObject as? NSDictionary
        let userArray : NSArray? = userDataInfo?.objectForKey("RoleInfo") as? NSArray
        
        itemList = NSMutableArray(array:userArray!)
        tblList.reloadData()
        NSNotificationCenter.defaultCenter().removeObserver(self, name: "LoginResponseResult", object: nil)
    }
}

