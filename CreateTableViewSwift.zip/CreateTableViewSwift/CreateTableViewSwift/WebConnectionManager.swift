//
//  WebConnectionManager.swift
//  CreateTableViewSwift
//
//  Created by Siya Infotech on 06/08/15.
//  Copyright (c) 2015 Siya Infotech. All rights reserved.
//

import Foundation


class WebConnectionManager : NSObject ,NSURLConnectionDataDelegate{
    
    var data = NSMutableData()
    var notificationName : NSString = ""
    
    func ConnectWithPOST(strUrl : NSString, ActionName strAction : NSString , WithParamiterList dictParamiterList : NSDictionary ,NotificationName notificationName : NSString){
        
        self.notificationName=notificationName
        var url = NSURL(string: strUrl)
        let data = NSJSONSerialization.dataWithJSONObject(dictParamiterList, options: nil, error: nil)
        let string = NSString(data: data!, encoding: NSUTF8StringEncoding)
        
        var request = NSMutableURLRequest(URL: url!)
        
        let requestData = string?.dataUsingEncoding(NSUTF8StringEncoding)
        
        request.HTTPMethod = "POST"
        request.HTTPBody=requestData
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
//        request.setValue(lenght.description, forHTTPHeaderField: "Content-Length")
        request.addValue("RapidRMS10015", forHTTPHeaderField: "DBName-Header")
        var postConnection = NSURLConnection(request: request, delegate: self, startImmediately: false)
        
        println("sending request...")
        
        postConnection?.start()
    }
    func sendNotification(strNotification : NSString){
        NSNotificationCenter.defaultCenter().postNotificationName(strNotification, object: nil)
    }
    
//    MARK: - URLConnection -

    func connection(connection: NSURLConnection, didReceiveResponse response: NSURLResponse){
        
    }
    
    func connection(connection: NSURLConnection, didReceiveData data: NSData){
        self.data.appendData(data)
    }
    
    func connectionDidFinishLoading(connection: NSURLConnection){
        var jsonstring : NSString? = NSString(data: self.data,encoding: NSUTF8StringEncoding)
//        var userInfo = jsonstring as? Dictionary<String,String>
        var jsonData :NSData? = jsonstring?.dataUsingEncoding(NSUTF8StringEncoding)
        var error :NSError?
        let userInfo: NSDictionary? = NSJSONSerialization.JSONObjectWithData(jsonData!, options: nil,error: &error) as? NSDictionary
        
//        NSNotificationCenter.defaultCenter().postNotificationName(self.notificationName, object: anyObj)
//        NSNotificationCenter.defaultCenter().postNotificationName(self.notificationName, object: userInfo, userInfo: userInfo)
        NSNotificationCenter.defaultCenter().postNotificationName(self.notificationName, object: nil, userInfo: userInfo)
    }
}